=== Fripixel Crypto Quotation ===
Contributors: fripixel
Donate link: https://bit.ly/3AFaHO6
Tags: crypto, bitcoin, quotation, currency
Requires at least: 5.4
Tested up to: 5.8
Stable tag: 5.4
Requires PHP: 7.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Fripixel Crypto Quotation plugin, shows a list of crypto quotation values.

== Description ==
Fripixel Crypto Quotation plugin, shows a list of crypto quotation values from Coin Market website.

== Frequently Asked Questions ==

= How can i insert use this plugin? =

This is a shortcode plugin just follow README.md instructions.

== Screenshots ==

1. This is the visual of the screenshot

== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade. No more than 300 characters.